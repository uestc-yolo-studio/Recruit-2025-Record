import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.nn.functional as F


transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.1307,), (0.3081,))])
train0=datasets.MNIST('./data', train=True, download=True, transform=transform)
test0=datasets.MNIST('./data', train=False, download=True, transform=transform)
train1= DataLoader(train0, batch_size=64, shuffle=True)
test1= DataLoader(test0, batch_size=1000, shuffle=False)


class C(nn.Module):
   def __init__(self):
       super(C, self).__init__()
       self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
       self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
       self.fc1 = nn.Linear(320, 50)
       self.fc2 = nn.Linear(50, 10)
   def forward(self, x):
       x = F.relu(F.max_pool2d(self.conv1(x), 2))
       x = F.relu(F.max_pool2d(self.conv2(x), 2))
       x = x.view(-1, 320)   #展平
       x = F.relu(self.fc1(x))
       x = self.fc2(x)
       return F.log_softmax(x, dim=1)


model = C()
import torch.optim as optim
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.5)


def train(model, device, train_loader, optimizer, epoch):
   model.train()
   for batch_idx, (data, target) in enumerate(train_loader):
       data,target=data.to(device), target.to(device)
       optimizer.zero_grad()
       output=model(data)
       loss=criterion(output, target)
       loss.backward()
       optimizer.step()
       if batch_idx%100==0:
           print(f'i{epoch} [{batch_idx * len(data)}/{len(train_loader.dataset)}]loss:{loss.item():.6f}')
def test(model, device, test_loader):
   model.eval()
   test_loss = 0
   correct = 0
   with torch.no_grad():
       for data, target in test_loader:
           data, target = data.to(device), target.to(device)
           output = model(data)
           test_loss += criterion(output, target).item()
           pred = output.argmax(dim=1)
           correct += pred.eq(target).sum().item()
   test_loss /= len(test_loader.dataset)
   print(f'\nloss:{test_loss:.4f}, {correct}/{len(test_loader.dataset)} ({100.*correct / len(test_loader.dataset):.0f}%)\n')


de = torch.device("cuda")
model.to(de)
for epoch in range(1, 11):
   train(model,de,train1,optimizer,epoch)
   test(model,de,test1)