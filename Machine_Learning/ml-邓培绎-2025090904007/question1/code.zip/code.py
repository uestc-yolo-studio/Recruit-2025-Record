import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import random

t=100
l=0.001
i=0
x0=random.uniform(-0.5,1.5)
x=sp.symbols('x')
f=2*x**5+x**4-11*x**3+7*x**2+2*x
f1=sp.diff(f,x)


xh=np.linspace(-0.5,1.5,100)
fh=2*xh**5+xh**4-11*xh**3+7*xh**2+2*xh
plt.xlim(-0.5,1.5)
plt.ylim(-1,2)


for i in range(t):
    y0=f.subs(x,x0)
    x0=x0-l*f1.subs(x,x0)
    plt.scatter(x0,y0)
print(x0,y0)

plt.plot(xh,fh)
plt.show()
