import numpy as np
import sympy as sp
import matplotlib.pyplot as plt

xt=np.linspace(-0.5,1.5,50)
yt=2*xt**5+xt**4-11*xt**3+7*xt**2+2*xt
xs=np.linspace(-0.5,1.5,50)
w5,w4,w3,w2,w1=3,3,-7,4,3
ws=np.array([w1,w2,w3,w4,w5])
ys=w5*xs**5+w4*xs**4+w3*xs**3+w2*xs**2+w1*xs
l=0.05
t=50


def ge(xs,yt,ws):
    w5,w4,w3,w2,w1=sp.symbols('w1 w2 w3 w4 w5')
    ge0=np.array([0,0,0,0,0])
    for xss,ytt in zip(xs,yt):
        f=(w5*xss**5+w4*xss**4+w3*xss**3+w2*xss**2+w1*xss-ytt)**2
        f1=sp.diff(f,w1)
        f2=sp.diff(f,w2)
        f3=sp.diff(f,w3)
        f4=sp.diff(f,w4)
        f5=sp.diff(f,w5)
        t={w1:ws[0],w2:ws[1],w3:ws[2],w4:ws[3],w5:ws[4]}
        ge1=np.array([f1.subs(t),f2.subs(t),f3.subs(t),f4.subs(t),f5.subs(t)])
        ge0=ge0+ge1
    return ge0/len(xs)


for i in range(5):
    ys=ws[4]*xs**5+ws[3]*xs**4+ws[2]*xs**3+ws[1]*xs**2+ws[0]*xs
    ge1=ge(xs,yt,ws)
    ws=ws-l*ge1
plt.plot(xt,yt)
plt.plot(xs,ys)
plt.show()