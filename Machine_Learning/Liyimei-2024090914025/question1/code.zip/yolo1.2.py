# -*- coding: GB2312 -*-
import numpy as np
import matplotlib.pyplot as plt

x=np.linspace(-0.5,1.5,100)
true_a=2
true_b=1
true_c=-11
true_d=7
true_e=2
y_true=true_a*x**5+true_b*x**4+true_c*x**3+true_d*x**2+true_e*x
a,b,c,d,e=0.0,0.0,0.0,0.0,0.0
learning_rate=0.1
times=200000
loss_history=[]

for i in range(times):
    # ����Ԥ��ֵ
    y_pred=a*x**5+b*x**4+c*x**3+d*x**2+e*x
    # ������������ʧ
    loss=np.mean((y_pred-y_true)**2)
    loss_history.append(loss)
    # �����ݶ�
    grad_a=np.mean(2*(y_pred-y_true)*x**5)
    grad_b=np.mean(2*(y_pred-y_true)*x**4)
    grad_c=np.mean(2*(y_pred-y_true)*x**3)
    grad_d=np.mean(2*(y_pred-y_true)*x**2)
    grad_e=np.mean(2*(y_pred-y_true)*x)
    a-=learning_rate*grad_a
    b-=learning_rate*grad_b
    c-=learning_rate*grad_c
    d-=learning_rate*grad_d
    e-=learning_rate*grad_e

plt.figure(figsize=(13,7))
plt.plot(loss_history)
plt.xlabel('Times')
plt.ylabel('MSE Loss')
plt.title('Loss During Coefficient Fitting')
plt.grid(True)
plt.show()

print("\n�������ϵ����")
print(f"a={a:.4f},b={b:.4f},c={c:.4f},d={d:.4f},e={e:.4f}")
print("��ʵϵ����a=2,b=1,c=-11,d=7,e=2")