import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForCausalLM
#自注意力机制
class SelfAttention(nn.Module):
    #初始化
    def __init__(self,embed_size,heads):
        super(SelfAttention,self).__init__()
        self.embed_size=embed_size
        self.heads=heads
        self.head_dim=embed_size//heads
        assert self.head_dim*heads==embed_size,"Embedding size needs to be divisible by heads"
        self.values=nn.Linear(embed_size,heads*self.head_dim,bias=False)
        self.keys=nn.Linear(embed_size,heads*self.head_dim,bias=False)
        self.queries=nn.Linear(embed_size,heads*self.head_dim,bias=False)
        self.fc_out=nn.Linear(heads*self.head_dim,embed_size)
    #前向传播    
    def forward(self,values,keys,query,mask):
        N=query.shape[0]
        value_len,key_len,query_len=values.shape[1],keys.shape[1],query.shape[1]
        values=self.values(values)
        keys=self.keys(keys)
        queries=self.queries(query)
        values=values.reshape(N,value_len,self.heads,self.head_dim)
        keys=keys.reshape(N,key_len,self.heads,self.head_dim)
        queries=queries.reshape(N,query_len,self.heads,self.head_dim)
        energy=torch.einsum("nqhd,nkhd->nhqk",[queries,keys])
        if mask is not None:
            energy=energy.masked_fill(mask==0,float("-1e20"))
        attention=torch.softmax(energy/(self.head_dim**0.5),dim=3)
        out=torch.einsum("nhql,nlhd->nqhd",[attention,values])
        out=out.reshape(N,query_len,self.heads*self.head_dim)
        return self.fc_out(out)
#Transformer块
class TransformerBlock(nn.Module):
    #初始化
    def __init__(self,embed_size,heads,dropout,forward_expansion):
        super(TransformerBlock,self).__init__()
        self.attention=SelfAttention(embed_size,heads)
        self.norm1=nn.LayerNorm(embed_size)
        self.norm2=nn.LayerNorm(embed_size)
        self.feed_forward=nn.Sequential(
            nn.Linear(embed_size,forward_expansion*embed_size),
            nn.GELU(),
            nn.Linear(forward_expansion*embed_size,embed_size)
        )
        self.dropout=nn.Dropout(dropout)
    #前向传播
    def forward(self,value,key,query,mask):
        attention=self.attention(value,key,query,mask)
        x=self.dropout(self.norm1(attention+query))
        forward=self.feed_forward(x)
        out=self.dropout(self.norm2(forward+x))
        return out
#旋转位置编码（RoPE），让模型感知token的顺序信息，比GPT-2原始的正弦位置编码更优
class RotaryPositionEmbedding(nn.Module):
    #初始化
    def __init__(self,dim,max_seq_len=4096,base=10000):
        super().__init__()
        self.dim=dim
        self.max_seq_len=max_seq_len
        self.base=base
        inv_freq=1.0/(base**(torch.arange(0,dim,2).float()/dim))
        self.register_buffer("inv_freq",inv_freq)
    #前向传播
    def forward(self,x):
        seq_len,_=x.shape
        t=torch.arange(seq_len,device=x.device).type_as(self.inv_freq)
        freqs=torch.einsum("i,j->ij",t,self.inv_freq)
        emb=torch.cat((freqs.sin(),freqs.cos()),dim=-1)
        emb=emb[None,:,:]
        x_rot=x[...,:self.dim//2]
        x_pass=x[...,self.dim//2:]
        x1,x2=x_rot.chunk(2,dim=-1)
        cos,sin=emb.chunk(2,dim=-1)
        x_rot=torch.cat([x1*cos-x2*sin,x2*cos+x1*sin],dim=-1)
        return torch.cat([x_rot,x_pass],dim=-1)
#简化版GPT-2模型
class GPT2Simplified(nn.Module):
    #初始化
    def __init__(self,vocab_size,embed_size=768,num_layers=12,heads=12,forward_expansion=4,dropout=0.1,max_length=1024):
        super(GPT2Simplified,self).__init__()
        self.embed_size=embed_size
        self.token_embedding=nn.Embedding(vocab_size,embed_size)
        self.pos_embedding=RotaryPositionEmbedding(embed_size,max_length)
        self.layers=nn.ModuleList([TransformerBlock(embed_size,heads,dropout,forward_expansion) for _ in range(num_layers)])
        self.dropout=nn.Dropout(dropout)
        self.fc_out=nn.Linear(embed_size,vocab_size)
        self.apply(self._init_weights)
    #权重初始化
    def _init_weights(self,module):
        if isinstance(module,nn.Linear):
            torch.nn.init.normal_(module.weight,mean=0.0,std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module,nn.Embedding):
            torch.nn.init.normal_(module.weight,mean=0.0,std=0.02)
        elif isinstance(module,nn.LayerNorm):
            torch.nn.init.zeros_(module.bias)
            torch.nn.init.ones_(module.weight)
    #前向传播
    def forward(self,x,mask=None):
        out=self.token_embedding(x)
        out=self.pos_embedding(out)
        out=self.dropout(out)
        for layer in self.layers:
            out=layer(out,out,out,mask)
        return self.fc_out(out)
    #文本生成，自回归生成逻辑
    def generate(self,idx,max_new_tokens,temperature=1.0,top_k=None):
        for _ in range(max_new_tokens):
            idx_cond=idx if idx.size(1)<=self.pos_embedding.max_seq_len else idx[:,-self.pos_embedding.max_seq_len:]
            logits=self(idx_cond)
            logits=logits[:,-1,:]/temperature
            if top_k is not None:
                v,_=torch.topk(logits,min(top_k,logits.size(-1)))
                logits[logits<v[:,[-1]]]=-float('Inf')
            probs=F.softmax(logits,dim=-1)
            idx_next=torch.multinomial(probs,num_samples=1)
            idx=torch.cat((idx,idx_next),dim=1)
        return idx
#MikuChatbot聊天机器人
class MikuChatbot:
    #初始化
    def __init__(self,use_pretrained=True,model_name="uer/gpt2-chinese-cluecorpussmall"):
        self.device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"使用设备: {self.device}")
        self.miku_personality="初音未来是虚拟歌手，性格活泼可爱，喜欢音乐和唱歌，用中文交流时会带可爱表情，回复要贴合灵梦的问题，语气热情友好。"
        if use_pretrained:
            self.tokenizer=AutoTokenizer.from_pretrained(model_name)
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token=self.tokenizer.eos_token
            self.model=AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
            self.model.eval()
        else:
            vocab_size=50000
            self.model=GPT2Simplified(vocab_size).to(self.device)
            self.tokenizer=None
    #生成回复
    def generate_response(self,input_text,max_length=100,temperature=0.8,top_k=40,top_p=0.9,repetition_penalty=1.5):
        if hasattr(self,'tokenizer') and self.tokenizer is not None:
            prompt=f"灵梦: {input_text}\n初音未来:"
            inputs=self.tokenizer.encode(prompt,return_tensors='pt').to(self.device)
            input_len=inputs.shape[1]
            with torch.no_grad():
                outputs=self.model.generate(
                    inputs,
                    max_length=input_len+max_length,
                    temperature=temperature,
                    top_k=top_k,
                    top_p=top_p,
                    repetition_penalty=repetition_penalty,
                    do_sample=True,
                    num_beams=1,
                    no_repeat_ngram_size=3,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                )
            full_text=self.tokenizer.decode(outputs[0],skip_special_tokens=True)
            response_parts=full_text.split("初音未来:")
            generated_content=response_parts[-1].strip() if len(response_parts)>1 else ""
            unwanted_prefixes=["灵梦:","灵梦：","灵梦: ","灵梦： "]
            for prefix in unwanted_prefixes:
                if generated_content.startswith(prefix):
                    generated_content=generated_content[len(prefix):].strip()
                if prefix in generated_content:
                    generated_content=generated_content.split(prefix)[0].strip()
            response=generated_content.strip()
            end_symbols=['。','！','？','～','♪',')','】',';','；']
            for sym in end_symbols:
                if sym in response:
                    response=response[:response.index(sym)+1].strip()
                    break
            if not response or len(response)<5:
                default_responses_map={
                    "虚拟歌手":"你好呀～ 我是初音未来～ 很高兴认识你！(≧∇≦)ﾉ",
                    "唱什么样的歌":"我会唱很多类型的歌哦～ 比如《甩葱歌》！想听吗？♪",
                    "虚拟存在":"虚拟存在的话…就像一直能和大家通过音乐连接在一起呀～(*^▽^*)",
                    "演唱会":"哇！能在博丽神社开演唱会一定很有趣！我超想试试的～",
                    "再和你说话":"当然可以啦～ 随时来找我聊天都可以哦～ 我会一直在这里的～(๑•̀ㅂ•́)و✧"
                }
                matched_key=None
                for key in default_responses_map:
                    if key in input_text:
                        matched_key=key
                        break
                if matched_key:
                    response=default_responses_map[matched_key]
                else:
                    default_responses=[
                        "你好呀～ 很高兴见到你！(≧∇≦)ﾉ",
                        "灵梦小姐，这个问题好有趣～ 我想想哦…",
                        "我很喜欢唱歌哦～ 想听吗？♪",
                        "幻想乡听起来很有趣呢！能多讲讲吗？",
                        "今天天气真好呀～ 适合唱歌呢！"
                    ]
                    response=default_responses[hash(input_text)%len(default_responses)]
            return response
        else:
            responses=[
                "你好呀！我是初音未来～ 很高兴认识你！(≧∇≦)ﾉ",
                "灵梦小姐，你的神社看起来很安静呢～ 想不想听我唱歌？",
                "幻想乡好像是个很有趣的地方呢！有机会真想去看看！",
                "音乐是跨越次元的语言哦～ 不管在哪里，大家都能感受到音乐的力量！",
                "谢谢你和我聊天呀～ 这让我很开心！(*^▽^*)"
            ]
            return responses[hash(input_text)%len(responses)]
    
def main():
    print("🎌 博丽灵梦与初音未来的对话 🎌")
    print("="*50)
    chatbot=MikuChatbot(use_pretrained=True)
    dialogues=[
        "你好，初音未来！我是博丽神社的巫女博丽灵梦。听说你是一位很受欢迎的虚拟歌手呢。",
        "在我们幻想乡，也有很多喜欢音乐的人。你会唱什么样的歌呀？",
        "虚拟存在是什么样的感觉呢？和我们人类有什么不同吗？",
        "如果有机会，真想在博丽神社举办一场你的演唱会呢！",
        "谢谢你今天陪我聊天，我很开心。以后还能再和你说话吗？"
    ]
    for dialogue in dialogues:
        print(f"灵梦: {dialogue}")
        response=chatbot.generate_response(dialogue)
        print(f"初音未来: {response}")
        print("-"*50)

if __name__=="__main__":
    main()