# -*- coding: utf-8 -*-
import torch
import torch.nn as nn   #包含神经网络层
import torch.optim as optim    #包含优化器
from torchvision import datasets,transforms    #处理视觉数据
import matplotlib.pyplot as plt
import matplotlib

matplotlib.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
matplotlib.rcParams["axes.unicode_minus"] = False  # 确保负号正常显示

class LeNet(nn.Module):
    def __init__(self):
        super(LeNet,self).__init__()
        #第一个卷积块：卷积层+ReLU激活函数+池化层
        self.conv1=nn.Conv2d(1,6,kernel_size=5)
        self.relu1=nn.ReLU()
        self.pool1=nn.MaxPool2d(kernel_size=2,stride=2)
        #第二个卷积块：卷积层+ReLU激活函数+池化层
        self.conv2=nn.Conv2d(6,16,kernel_size=5)
        self.relu2=nn.ReLU()
        self.pool2=nn.MaxPool2d(kernel_size=2,stride=2)
        #全连接层
        self.fc1=nn.Linear(16*4*4,120)
        self.relu3=nn.ReLU()
        self.fc2=nn.Linear(120,84)
        self.relu4=nn.ReLU()
        self.fc3=nn.Linear(84,10)
    #前向传播
    def forward(self,x):
        x=self.relu1(self.conv1(x))
        x=self.pool1(x)
        x=self.relu2(self.conv2(x))
        x=self.pool2(x)
        x=x.view(-1,16*4*4)   #展平
        x=self.relu3(self.fc1(x))
        x=self.relu4(self.fc2(x))
        x=self.fc3(x)
        return x
#数据预处理
transform=transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,),(0.3081,)) #MNIST数据集的均值和标准差
])
#加载训练数据集
train_dataset=datasets.MNIST(
    root='./data',
    train=True,
    download=True,
    transform=transform
)
#加载测试数据集
test_dataset=datasets.MNIST(
    root='./data',
    train=False,
    download=True,
    transform=transform
)
#创建训练数据加载器
train_loader=torch.utils.data.DataLoader(
    train_dataset,
    batch_size=64,
    shuffle=True
)
#创建测试数据加载器
test_loader=torch.utils.data.DataLoader(
    test_dataset,
    batch_size=64,
    shuffle=False
)

device=torch.device("cuda")
model=LeNet().to(device)
criterion=nn.CrossEntropyLoss()  #损失函数
optimizer=optim.Adam(model.parameters(),lr=0.001)  #优化器

def train(model,train_loader,criterion,optimizer,epochs=5):
    train_losses=[]
    model.train()
    for epoch in range(epochs):
        running_loss=0.0
        for batch_idx,(inputs,labels) in enumerate(train_loader):
            inputs,labels=inputs.to(device),labels.to(device)
            optimizer.zero_grad()   #清零梯度
            outputs=model(inputs)
            loss=criterion(outputs,labels)
            loss.backward()
            optimizer.step()    #更新参数
            running_loss+=loss.item()
            if batch_idx%100==99:
                print(f'Epoch[{epoch+1}/{epochs}],Batch[{batch_idx+1}/{len(train_loader)}],Loss:{loss.item():.4f}')
        epoch_loss=running_loss/len(train_loader)
        train_losses.append(epoch_loss)
        print(f'Epoch [{epoch+1}/{epochs}]完成,平均损失: {epoch_loss:.4f}')
    #绘图
    plt.figure(figsize=(10,6))
    plt.plot(range(1,epochs+1),train_losses,marker='o')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss')
    plt.grid(True)
    plt.show()
    return model

def visualize_predictions(model,test_loader,device,num_samples=5):
    model.eval()  #设置模型为评估模式
    images,labels=next(iter(test_loader))
    images,labels=images[:num_samples].to(device),labels[:num_samples].to(device)
    #不计算梯度
    with torch.no_grad():
        outputs=model(images)
        _,predicted=torch.max(outputs,1)
    plt.figure(figsize=(10,4))
    for i in range(num_samples):
        plt.subplot(1,num_samples,i+1)
        plt.imshow(images[i].cpu().squeeze().numpy(),cmap='gray')
        plt.title(f'预测:{predicted[i].item()}\n真实:{labels[i].item()}')
        plt.axis('off')
    plt.tight_layout()
    plt.show()

def test(model,test_loader):
    model.eval()
    correct=0
    total=0
    with torch.no_grad():
        for inputs,labels in test_loader:
            inputs,labels=inputs.to(device),labels.to(device)
            outputs=model(inputs)
            _,predicted=torch.max(outputs.data,1)
            total+=labels.size(0)
            correct+=(predicted==labels).sum().item()
    accuracy=100*correct/total
    print(f'测试集准确率: {accuracy:.2f}%')
    visualize_predictions(model,test_loader,device)

trained_model=train(model,train_loader,criterion,optimizer,epochs=5)
test(trained_model,test_loader)