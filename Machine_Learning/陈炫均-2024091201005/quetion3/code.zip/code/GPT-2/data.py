import os
import requests

url = "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"
response = requests.get(url)
with open("tinyshakespeare/input.txt", "w") as f:
    f.write(response.text)