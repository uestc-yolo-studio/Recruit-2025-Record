from dataclasses import dataclass
import torch
import torch.nn as nn
from torch.nn import functional as F
from transformers import GPT2Config
from transformers.models.deprecated.trajectory_transformer.modeling_trajectory_transformer import CausalSelfAttention
import math
import tiktoken

@dataclass
class GPTConfig:
    # 最大序列长度
    block_size: int = 1024
    # 字典大小
    vocab_size: int = 50257
    # 层数
    n_layer: int = 12
    # 注意力投头数
    n_head: int = 12
    # 嵌入维度
    n_embd: int = 768



# 多头自注意力的实现
class CausalSelfAttention1(nn.Module):
    def __init__(self, config):
        super().__init__()
        assert config.n_embd % config.n_head == 0
        """
        线性层 c_attn，
        用于处理注意力机制中的query、key和value。
        输出维度是 3 * config.n_embd，
        因为查询、键和值的维度加起来是嵌入维度的三倍。
        """
        self.c_attn = nn.Linear(config.n_embd, 3 * config.n_embd)
        """
        线性层 c_proj，
        用于将注意力机制的输出投影回原始的嵌入维度。
        """
        self.c_proj = nn.Linear(config.n_embd, config.n_embd)
        self.c_proj.NANOGPT_SCALE_INIT = 1
        # 存储头数，用于多头注意力机制
        self.n_head = config.n_head
        # 存储嵌入维度，用于定义向量的大小
        self.n_embd = config.n_embd
        # 注册一个缓冲区bias，用于存储一个下三角矩阵，用于实现因果掩码
        self.register_buffer("bias", torch.tril(torch.ones(config.block_size, config.block_size)).view(1, 1, config.block_size, config.block_size))

    def forward(self, x):
        # 获取输入x的维度，其中B是批次大小，T是序列长度，C是即嵌入维度
        B, T, C = x.size()
        # 通过线性层c_attn处理输入x，生成查询、键和值。输出qkv的形状为(B,T,3*C)
        qkv = self.c_attn(x)
        # 将qkv张量沿着最后一个维度（特征维度）分割成三份，每份的形状为(B,T,C)，分别对应Q、K、V
        q, k, v = qkv.split(self.n_embd, dim=2)
        """
        将Q、K、V重塑为(B,num_heads,T,head_dim)的形状，
        其中head_dim=C//self.n_head是每个头的维度，
        然后通过.transpose(1,2) 将时间步维度T和头数维度num_heads交换位置，
        以适应多头注意力的计算
        """
        q = q.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        k = k.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        v = v.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        # 计算Q和K的点积，得到原始的注意力分数。然后除以sqrt(head_dim)进行缩放，以防止点积结果过大
        attn = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(k.size(-1)))
        # 应用因果掩码
        attn = attn.masked_fill(self.bias[:,:,:T, :T] == 0, float('-inf'))
        # 得到每个头的注意力权重。
        attn = F.softmax(attn, dim=-1)
        # 使用注意力权重对V进行加权求和，得到加权的值向量
        y = attn @ v
        """
        将时间步维度T和头数维度num_heads交换回来，
        然后使用.contiguous()和.view(B, T, C), 
        将输出张量y重塑回原始的(B,T,C)形状。
        """
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        # 投影回原始的嵌入维度C
        y = self.c_proj(y)
        return y


# MLP的实现
class MLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        # 线性层
        self.c_fc = nn.Linear(config.n_embd, 4 * config.n_embd)
        # 线性层
        self.c_proj = nn.Linear(4 * config.n_embd, config.n_embd)
        self.c_fc.NANOGPT_SCALE_INIT = 1
        # 激活函数(与relu类似，但在小于零时不会完全平坦)
        self.gelu = nn.GELU(approximate="tanh")

    def forward(self, x):
        x = self.c_fc(x)
        x = self.gelu(x)
        x = self.c_proj(x)
        return x





# 模型快
class Block(nn.Module):
    def __init__(self, config):
        super().__init__()
        # 层规范层
        self.ln_1 = nn.LayerNorm(config.n_embd)
        # 层规范层
        self.ln_2 = nn.LayerNorm(config.n_embd)
        # 自注意力层，有信息的交织，归约作用
        self.attn = CausalSelfAttention1(config)
        # 多层感知器，无信息的交织，映射作用（需手动实现）
        self.mlp = MLP(config)

    def forward(self, x):
        """
        x先经过一层层规范层，
        然后再经过自注意力层，
        加上残差后，再过一层规范层，
        最后再过MLP层，再加上残差
        """
        x = x + self.attn(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x




# 骨干部分
class GPT(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        # 所有模块以transformer作为主容器
        self.transformer = nn.ModuleDict(dict(
            # 词汇嵌入层
            wte = nn.Embedding(config.vocab_size, config.n_embd),
            # 位置嵌入层
            wpe = nn.Embedding(config.block_size, config.n_embd),
            # transformer层（需手动实现）
            h = nn.ModuleList([Block(config) for _ in range(config.n_layer)]),
            # 最终的层归一化
            ln_f = nn.LayerNorm(config.n_embd),
        ))
        # 语言模型头，最终的分类器
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)

        # 权重共享，论文中词汇嵌入层的权重和语言模型头的权重是共享的
        self.transformer.wte.weight = self.lm_head.weight

        # 权重初始化
        self.apply(self._init_weights)

    # 论文中采用正态分布
    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            std = 0.02
            if hasattr(module, 'NANOGPT_SCALE_INIT'):
                std *= (2 * self.config.n_layer) ** -0.5
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, idx, targets=None):

        # 获取输入idx的维度，其中B是批次大小，T是序列长度
        B, T = idx.size()
        # 确保序列长度T不超过模型的最大块大小config.block_size
        assert T <= self.config.block_size, f"Cannot forward sequence of length {T}, block size is {self.config.block_size}."
        # 创建一个位置索引张量pos，从0到T-1，用于位置编码
        pos = torch.arange(0, T, dtype=torch.long, device=idx.device)
        # 通过位置嵌入层wpe获取位置嵌入向量
        pos_emb = self.transformer.wpe(pos)
        # 通过词汇嵌入层wte获取词汇嵌入向量
        token_emb = self.transformer.wte(idx)
        # 词汇嵌入向量和位置嵌入向量相加，得到输入嵌入向量
        x = token_emb + pos_emb
        # 遍历所有Transformer层
        for block in self.transformer.h:
            x = block(x)
        # 最终的层归一化层ln_f对输出进行归一化
        x = self.transformer.ln_f(x)
        # 通过语言模型头lm_head将归一化后的输出映射到词汇表大小的空间，得到最终的分类结果
        logits = self.lm_head(x)
        loss = None
        if targets is not None:
        # 将logits从(B,T,vocab_size)变为(B*T,vocab_size)，将targets从(B,T)变为(B*T)
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))
        return logits,  loss

    @classmethod
    def from_pretrained(cls, model_type):
        # 确保model_type是一个有效的预训练模型类型
        assert model_type in {"gpt2", "gpt2-medium", "gpt2-large", "gpt2-xl"}
        from transformers import GPT2LMHeadModel
        print(f"Loading pretrained GPT-2 {model_type} model...")
        # 根据model_type，从字典中选择对应的模型配置参数
        config_args = {
            "gpt2": dict(n_layer = 12, n_head = 12, n_embd = 768),# 124m
            "gpt2-medium": dict(n_layer=24, n_head=16, n_embd=1024),# 355m
            "gpt2-large": dict(n_layer=36, n_head=20, n_embd=1280),# 774m
            "gpt2-xl": dict(n_layer=48, n_head=25, n_embd=1600),# 1558m
        }[model_type]
        config_args["vocab_size"] = 50257
        config_args["block_size"] = 1024
        # 使用配置参数创建一个GPT2Config对象
        config = GPT2Config(**config_args)
        # 创建一个自定义的GPT模型实例
        model = GPT(config)
        # 获取自定义模型的状态字典（state_dict），它包含了模型的所有权重和偏置
        sd = model.state_dict()
        # 获取状态字典的所有键（权重名称），并过滤掉以.attn.bias结尾的键，因为这些键在HuggingFace的模型中不存在
        sd_keys = sd.keys()
        sd_keys = [k for k in sd_keys if not k.endswith('.attn.bias')]
        # 加载模型
        model_hf = GPT2LMHeadModel.from_pretrained(model_type)
        # 获取加载的HuggingFace模型的状态字典
        sd_hf = model_hf.state_dict()
        # 获取HuggingFace模型的状态字典的所有键，并过滤掉以.attn.masked_bias和.attn.bias结尾的键
        sd_keys_hf = sd_hf.keys()
        sd_keys_hf = [k for k in sd_keys_hf if not k.endswith('.attn.masked_bias')]
        sd_keys_hf = [k for k in sd_keys_hf if not k.endswith('.attn.bias')]
        # 定义一个列表，包含需要转置的权重名称。这些权重在HuggingFace的模型中是转置的，而在自定义模型中不是
        transposed = ['attn.c_attn.weight', 'attn.c_proj.weight', 'mlp.c_fc.weight', 'mlp.c_proj.weight']
        # 确保自定义模型和Hugging Face模型的状态字典中的键数量一致
        assert len(sd_keys) == len(sd_keys_hf), f"mismatched keys: {len(sd_keys)} in HF vs {len(sd_keys_hf)} in GPT2"
        # 遍历HuggingFace模型的状态字典中的所有键
        for k in sd_keys_hf:
            """
            如果键k是需要转置的权重之一，
            检查HuggingFace模型的权重形状是否与自定义模型的权重形状一致（转置后）
            如果一致，将HuggingFace模型的权重转置后复制到自定义模型中
            """
            if any(k.endswith(w) for w in transposed):
                assert sd_hf[k].shape[::-1] == sd[k].shape
                with torch.no_grad():
                    sd[k].copy_(sd_hf[k].t())
            # 如果键k不是需要转置的权重，
            # 检查HuggingFace模型的权重形状是否与自定义模型的权重形状一致
            # 如果一致，将HuggingFace模型的权重直接复制到自定义模型中
            else:
                assert sd_hf[k].shape == sd[k].shape, f"{k} failed: {sd_hf[k].shape} != {sd[k].shape}"
                with torch.no_grad():
                    sd[k].copy_(sd_hf[k])
        return  model


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 定义数据加载器
class DataLoaderLite:
    def __init__(self, B, T):
        self.B = B
        self.T = T

        with open('tinyshakespeare\\input.txt', 'r', encoding='utf-8') as f:
            text = f.read()
        enc = tiktoken.get_encoding("gpt2")
        # 编码文本
        tokens = enc.encode(text)
        self.tokens = tokens
        print(f"loaded {len(tokens)} tokens")
        print(f"1 epoch = {(len(self.tokens)) // (B * T)} batches")
        # 初始化当前读取位置为0，用于跟踪数据加载的进度
        self.current_position = 0

    def next_batch(self):
        B, T = self.B, self.T
        # 从文本中提取从当前位置开始，长度为B*T的子序列，+1多取一个是标签
        buf = self.tokens[self.current_position : self.current_position + B * T + 1]
        buf = torch.tensor(buf, dtype=torch.long)
        # x是buf从第一个标记到倒数第二个标记的部分
        x = (buf[:-1]).view(B, T)
        # y是buf从第二个标记到最后一个标记的部分
        y = (buf[1:]).view(B, T)
        # x,y均是二维数组

        # 更新当前读取的位置
        self.current_position += B * T
        # 检查是否已经到达数据集的末尾
        if self.current_position + B * T >= len(self.tokens):
        # 是的话就重置位置，开始新一轮遍历
            self.current_position = 0
        return x, y

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device {device}")


model = GPT(GPTConfig)
model.to(device)

torch.manual_seed(1337)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(1337)


# 设置数据加载器
train_loader = DataLoaderLite(B=4, T=32)

# 设置优化器
optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4)

# 进行训练
for i in range(1000):
    x, y = train_loader.next_batch()
    x, y = x.to(device), y.to(device)
    optimizer.zero_grad()
    logits, loss = model(x, y)
    loss.backward()
    optimizer.step()
    print(f" step {i}: {loss.item()}")


torch.save(model, 'gpt_model.pth')


import sys; sys.exit(0)


