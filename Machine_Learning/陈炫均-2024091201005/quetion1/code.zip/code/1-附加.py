import numpy as np
import matplotlib.pyplot as plt


def Loss(a, b, c, d, e, x, y):
    return np.mean((a*x**5 + b*x**4 + c*x**3 + d*x**2 + e*x - y)**2)

def down2(x, y, lr,  ranges):
    a, b, c, d, e = np.random.randn(5)
    total_lost = []
    for i in range(ranges):
        pred = a*x**5 + b*x**4 + c*x**3 + d*x**2 + e*x
        difference = pred - y
        a -= lr * 2 * np.mean(difference * x**5)
        b -= lr * 2 * np.mean(difference * x**4)
        c -= lr * 2 * np.mean(difference * x**3)
        d -= lr * 2 * np.mean(difference * x**2)
        e -= lr * 2 * np.mean(difference * x)
        loss = Loss(a, b, c, d, e, x, y)
        total_lost.append(loss)
        print(f'Iteration {i+1}/{ranges}, Loss: {loss}')
    return a, b, c, d, e, total_lost





np.random.seed(0)
x = np.linspace(-0.5, 1.5, 100)
y = 2*x**5 + 3*x**4 - 4*x**3 + 5*x**2 + x
a, b, c, d, e, losses = down2(x, y, 0.007, 1000000)

plt.figure(figsize=(8, 6))
plt.plot(losses, label='Loss')
plt.ylabel('Loss')

plt.legend()
plt.grid(True)
plt.show()


print(f"a = {a}, b = {b}, c = {c}, d = {d}, e = {e}")