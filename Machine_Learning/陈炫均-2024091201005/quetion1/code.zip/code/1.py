import numpy as np
import matplotlib.pyplot as plt


def f(x):
    return 2*x**5 + x**4 - 11*x**3 + 7*x**2 + 2*x

x = np.linspace(-0.5, 1.5, 400)
y = f(x)

plt.figure(figsize=(8, 6))
plt.plot(x, y, label='y = 2x^5 + x^4 - 11x^3 + 7x^2 + 2x')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.show()

def d_f(x):
    return 10*x**4 + 4*x**3 - 33*x**2 + 14*x + 2

def down(f, d_f, x_begin, lr, ranges):
    for i in range(ranges):
        x_begin = x_begin - lr * d_f(x_begin)

    return x_begin

x_begin = np.random.uniform(-0.5, 1.5)
x_min = down(f, d_f, x_begin, 0.01, 1000)
print(x_min)