import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from model import Lenet

# 选择设备
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

# 设置模型
model = Lenet().to(device)

# 数据处理
transforms = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

# 设置数据集
train_dataset = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=transforms)
test_dataset = torchvision.datasets.MNIST(root='./data', train=False, download=True, transform=transforms)
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=8, shuffle=True, num_workers=16)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=8, shuffle=False, num_workers=16)

# 训练函数
def train(model, train_loader, optimizer, Loss, epochs):
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        for i, (inputs, labels) in enumerate(train_loader):
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            loss = Loss(outputs, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        avg_loss = total_loss / (i + 1)
        print(f"Epoch: {epoch}, Loss: {avg_loss}")
# 测试函数
def test(model, test_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    accuracy = correct / total
    print(f"Accuracy: {accuracy}")

# 优化器
optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

# 损失函数
Loss = nn.CrossEntropyLoss()

# 保证多线程运行
if __name__ == '__main__':
  train(model, train_loader, optimizer, Loss, 20)

  test(model, test_loader)