#**构建卷积神经网络LeNet**
#**加载pytorch官方所提供的MNIST数据集**
#**使用数据集中训练数据对模型进行训练**
#**使用训练后模型对数据集中测试数据进行检测并进行精确度计算**

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader

#torch：PyTorch 的核心库，用于张量操作和自动微分。
#torch.nn：包含构建神经网络所需的模块和层。
#torch.optim：包含各种优化算法，如 SGD、Adam 等。
#torchvision：提供数据集、模型和预训练权重等。
#torchvision.transforms：提供图像预处理功能。
#torch.utils.data.DataLoader：用于加载数据集并创建可迭代的数据加载器。

# 定义 LeNet 网络结构
#卷积层中的卷积核（也称为滤波器）起着非常重要的作用，
# 主要用于提取输入图像的局部特征。
class LeNet(nn.Module):
    def __init__(self):
        super(LeNet, self).__init__()
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5)  # 输入通道数为1，输出通道数为6，卷积核大小为5
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)  # 输入通道数为6，输出通道数为16，卷积核大小为5
        self.fc1 = nn.Linear(16 * 4 * 4, 120)  # 全连接层(线性层)，输入特征数为16*4*4，输出特征数为120
        self.fc2 = nn.Linear(120, 84)  # 全连接层，输入特征数为120，输出特征数为84
        self.fc3 = nn.Linear(84, 10)  # 全连接层，输入特征数为84，输出特征数为10（分类数）

    #x 是输入张量,
    #self.conv1(x) 返回的是一个张量。在 PyTorch 中，所有层（如卷积层、全连接层、池化层等）的前向传播方法都会返回一个张量，
    # 这个张量表示经过该层处理后的数据。
    def forward(self, x):
        x = torch.relu(torch.max_pool2d(self.conv1(x), 2))  # 卷积 + 激活 + 池化
        x = torch.relu(torch.max_pool2d(self.conv2(x), 2))  # 卷积 + 激活 + 池化
        #使用view方法将特征图展平为一维张量，以便输入到全连接层。
        x = x.view(-1, 16 * 4 * 4)  # 展平
        x = torch.relu(self.fc1(x))  # 全连接 + 激活
        x = torch.relu(self.fc2(x))  # 全连接 + 激活
        #输出层的原始分数（logits）：这些原始分数将被传递给损失函数（如交叉熵损失函数），用于计算分类损失。
        # 交叉熵损失函数可以直接处理这些原始分数，而不需要先通过ReLU函数。
        x = self.fc3(x)  # 输出层
        return x

# 设置超参数
batch_size = 64
learning_rate = 0.001
num_epochs = 10

# 数据预处理
#transforms.Compose：将多个预处理操作组合在一起
#transforms.Compose 是一个将多个预处理操作组合在一起的工具。它返回的是一个可调用对象（callable object）
# 这个对象可以对输入数据（通常是图像）依次应用一系列预处理操作。
transform = transforms.Compose([
    #transforms.ToTensor：将图片从 PIL 图像格式或 NumPy 数组转换为 PyTorch 张量，并将像素值归一化到 [0, 1]。
    transforms.ToTensor(),  # 将图片转换为Tensor，归一化至[0,1]
    #Normalize 方法中，mean 和 std 参数必须是元组。元组中只有一个元素，也需要在元素后面加上逗号
    transforms.Normalize((0.5,), (0.5,))  # 归一化至[-1,1]
])

# 加载 MNIST 数据集
#shuffle：是否在每个 epoch 开始时打乱数据。
train_dataset = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=transform)
test_dataset = torchvision.datasets.MNIST(root='./data', train=False, download=True, transform=transform)

#shuffle：是否在每个 epoch 开始时打乱数据。
#batch_size：这是每个批次加载的数据量。在训练过程中，通常不会一次性加载整个数据集，
# 而是将数据集分成多个小批次（batch），每次处理一个批次的数据
train_loader = DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(dataset=test_dataset, batch_size=batch_size, shuffle=False)

# 初始化模型、损失函数和优化器
#criterion：定义损失函数，这里使用交叉熵损失函数。
#optimizer：定义优化器，这里使用 Adam 优化器。
model = LeNet()
criterion = nn.CrossEntropyLoss()
#model.parameters() 是一个生成器，它会生成模型中所有需要优化的参数。
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# 训练模型
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    #DataLoader 返回的是一个可迭代对象，每次迭代会返回一个批次的数据和对应的标签
    #images 是一个张量（Tensor），包含了这个批次的所有图像数据；
    # labels 也是一个张量，包含了这个批次所有图像对应的标签
    for images, labels in train_loader:
        optimizer.zero_grad()  # 清空梯度
        #outputs：这是模型的输出，通常是一个二维张量，形状为 [batch_size, num_classes]。
        # 每一行表示一个样本的输出，每一列表示一个类别的预测值
        outputs = model(images)  # 前向传播
        loss = criterion(outputs, labels)  # 计算损失
        loss.backward()  # 反向传播
        optimizer.step()  # 更新参数
        running_loss += loss.item()
    print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {running_loss / len(train_loader):.4f}')

# 测试模型
#model.eval()：将模型设置为评估模式。
#禁用梯度计算
with torch.no_grad():
    correct = 0
    total = 0
    for images, labels in test_loader:
        #张量是一种多维数组，是深度学习中数据的基本表示形式。
        #outputs 是一个张量，形状通常是 [batch_size, num_classes]，表示每个样本在每个类别上的预测得分。
        outputs = model(images)
        
        #torch.max(outputs.data, 1) 返回两个值：
        # 第一个值是每个样本在所有类别上的最大预测得分。
        # 第二个值是这些最大预测得分对应的类别索引（即预测的类别）。
        # _是一个占位符，表示我们不关心最大预测得分，只关心预测的类别索引
        # predicted 是一个张量，形状为 [batch_size]，表示每个样本的预测类别
        _, predicted = torch.max(outputs.data, 1)
        #labels.size(0) 是当前批次的样本数量（即批次大小 batch_size）

        total += labels.size(0)
        #predicted == labels 是一个布尔张量，形状为 [batch_size]，表示每个样本的预测类别是否与真实标签一致。
        #(predicted == labels).sum() 计算这个布尔张量中 True 的数量，即当前批次中预测正确的样本数量。
        #.item() 将结果从张量转换为 Python 的标量值。
        correct += (predicted == labels).sum().item()
    print(f'Accuracy of the model on the test images: {100 * correct / total:.2f}%')