# **在区间 x[-0.5, 1.5] , y[-1, 2] 上绘制函数图形**
# **在 x 轴 [-0.5, 1.5] 范围内选取一个随机数，以梯度下降的思想更新 x ，使得 x 为取到 y 在原随机点附近的极小值**
# **将上述过程通过某种方法展示**
# **（附加）如果以上函数的系数分别为a, b, c, d, e，请尝试利用梯度下降法对系数进行拟合并输出，并画出损失函数图像。注：机器学习库只能使用Numpy**

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 定义函数
def func(x, y, a, b, c, d, e):
    return a*x**2 + b*y + c*x*y + d*x + e*y
#如果 x 和 y 是 数组，那么返回值是一个 数组，其中每个元素是对应位置的 x 和 y 计算的结果。

# 系数
a, b, c, d, e = 1, -1, 0.5, -0.5, 1

# 创建网格
x = np.linspace(-0.5, 1.5, 100)
y = np.linspace(-1, 2, 100)
#生成二维数组100*100，对于X，每行的值都相同；对于Y，每列的值都相同；相同的 x 值确实对应着不同的 y 值
X, Y = np.meshgrid(x, y)
Z = func(X, Y, a, b, c, d, e)

# 绘制图形
fig = plt.figure()
#添加子图，一行一列第一个图
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z, cmap='viridis')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
plt.show()

def gradient(x, y, a, b, c, d, e):
    df_dx = 2*a*x + c*y + d
    df_dy = b + c*x + e
    return df_dx, df_dy

# 初始点，返回一个浮点数
x_init = np.random.uniform(-0.5, 1.5)
y_init = np.random.uniform(-1, 2)

# 梯度下降参数
learning_rate = 0.01
iterations = 100

# 梯度下降过程
x, y = x_init, y_init
for i in range(iterations):         #迭代次数
    df_dx, df_dy = gradient(x, y, a, b, c, d, e)
    x -= learning_rate * df_dx
    y -= learning_rate * df_dy

print(f"极小值点: x = {x}, y = {y}")

# 记录梯度下降路径
#一维数组
path_x = [x_init]
path_y = [y_init]

x, y = x_init, y_init
for i in range(iterations):
    df_dx, df_dy = gradient(x, y, a, b, c, d, e)
    x -= learning_rate * df_dx
    y -= learning_rate * df_dy
    path_x.append(x)
    path_y.append(y)

# 绘制梯度下降路径
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot(path_x, path_y, func(np.array(path_x), np.array(path_y), a, b, c, d, e), 'r-')
ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.5)
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
plt.show()

# 生成数据
np.random.seed(0)
#返回数组
X_data = np.random.uniform(-0.5, 1.5, 100)
Y_data = np.random.uniform(-1, 2, 100)
#生成了一个包含 100 个随机数的数组，这些随机数服从均值为 0、标准差为 0.1 的正态分布
Z_data = func(X_data, Y_data, a, b, c, d, e) + np.random.normal(0, 0.1, 100)

# 初始化系数
a_init, b_init, c_init, d_init, e_init = 0, 0, 0, 0, 0

# 损失函数
#np.mean() 是 NumPy 库中的一个函数，用于计算数组的算术平均值（均值）
def loss(a, b, c, d, e, X, Y, Z):
    predictions = func(X, Y, a, b, c, d, e)
    return np.mean((predictions - Z) ** 2)

# 梯度，计算各个参数关于损失函数的偏导数
def gradient_loss(a, b, c, d, e, X, Y, Z):
    predictions = func(X, Y, a, b, c, d, e)
    errors = predictions - Z
    da = 2 * np.mean(errors * X**2)
    db = 2 * np.mean(errors * Y)
    dc = 2 * np.mean(errors * X * Y)
    dd = 2 * np.mean(errors * X)
    de = 2 * np.mean(errors * Y)
    return da, db, dc, dd, de

# 梯度下降参数
learning_rate = 0.01
iterations = 1000
losses = []

# 梯度下降过程
coefficients = [a_init, b_init, c_init, d_init, e_init]
for i in range(iterations):
    #解包列表
    da, db, dc, dd, de = gradient_loss(*coefficients, X_data, Y_data, Z_data)
    #zip 函数将 coefficients 列表和梯度值列表 [da, db, dc, dd, de] 配对，生成一个迭代器，每个元素是一个元组 (c,g)。
    coefficients = [c - learning_rate * g for c, g in zip(coefficients, [da, db, dc, dd, de])]
    losses.append(loss(*coefficients, X_data, Y_data, Z_data))

# 绘制损失函数图像
plt.plot(losses)
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function')
plt.show()

print("拟合系数:", coefficients)

